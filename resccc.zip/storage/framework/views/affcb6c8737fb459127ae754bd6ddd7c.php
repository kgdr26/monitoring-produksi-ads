<?php if(Route::currentRouteName()=='dasbor'): ?>simple-datatables
    <link href="<?php echo e(asset('assets/css/dasbor.css')); ?>" rel="stylesheet">
    <script type="text/javascript" src="<?php echo e(asset('assets/daterangepicker/daterangepicker.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/daterangepicker/datepicker.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/daterangepicker/bootstrap-datepicker.js')); ?>"></script>
<?php endif; ?>

<?php if(Route::currentRouteName()=='prodin'): ?>
    <link href="<?php echo e(asset('assets/css/in.css')); ?>" rel="stylesheet">
    <script type="text/javascript" src="<?php echo e(asset('assets/daterangepicker/daterangepicker.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/daterangepicker/datepicker.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/daterangepicker/bootstrap-datepicker.js')); ?>"></script>
<?php endif; ?>

<?php if(Route::currentRouteName()=='prodout'): ?>
    <link href="<?php echo e(asset('assets/css/out.css')); ?>" rel="stylesheet">
    <script type="text/javascript" src="<?php echo e(asset('assets/daterangepicker/daterangepicker.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/daterangepicker/datepicker.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/daterangepicker/bootstrap-datepicker.js')); ?>"></script>
<?php endif; ?>

<?php if(Route::currentRouteName()=='effmachine'): ?>
    <link href="<?php echo e(asset('assets/css/eff.css')); ?>" rel="stylesheet">
    <script type="text/javascript" src="<?php echo e(asset('assets/daterangepicker/daterangepicker.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/daterangepicker/datepicker.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/daterangepicker/bootstrap-datepicker.js')); ?>"></script>
<?php endif; ?>

<?php if(Route::currentRouteName()=='ppicschedule'): ?>
    <link href="<?php echo e(asset('assets/css/ppicschedule.css')); ?>" rel="stylesheet">
    <script type="text/javascript" src="<?php echo e(asset('assets/daterangepicker/daterangepicker.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/daterangepicker/datepicker.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/daterangepicker/bootstrap-datepicker.js')); ?>"></script>
    <link href="<?php echo e(asset('assets/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('assets/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<?php endif; ?>

<?php if(Route::currentRouteName()=='prodoutput'): ?>
    <link href="<?php echo e(asset('assets/css/prodoutput.css')); ?>" rel="stylesheet">
    <script type="text/javascript" src="<?php echo e(asset('assets/daterangepicker/daterangepicker.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/daterangepicker/datepicker.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/daterangepicker/bootstrap-datepicker.js')); ?>"></script>
    <link href="<?php echo e(asset('assets/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('assets/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<?php endif; ?>

<?php if(Route::currentRouteName()=='prodefisiensi'): ?>
    <link href="<?php echo e(asset('assets/css/prodefisiensi.css')); ?>" rel="stylesheet">
    <script type="text/javascript" src="<?php echo e(asset('assets/daterangepicker/daterangepicker.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/daterangepicker/datepicker.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/daterangepicker/bootstrap-datepicker.js')); ?>"></script>
    <link href="<?php echo e(asset('assets/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('assets/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<?php endif; ?>

<?php if(Route::currentRouteName()=='prodmanpower'): ?>
    <link href="<?php echo e(asset('assets/css/prodmanpower.css')); ?>" rel="stylesheet">
    <script type="text/javascript" src="<?php echo e(asset('assets/daterangepicker/daterangepicker.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/daterangepicker/datepicker.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/daterangepicker/bootstrap-datepicker.js')); ?>"></script>
    <link href="<?php echo e(asset('assets/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('assets/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<?php endif; ?>

<?php if(Route::currentRouteName()=='masterbaseprice'): ?>
    <link href="<?php echo e(asset('assets/css/masterbaseprice.css')); ?>" rel="stylesheet">
    <script type="text/javascript" src="<?php echo e(asset('assets/daterangepicker/daterangepicker.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/daterangepicker/datepicker.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/daterangepicker/bootstrap-datepicker.js')); ?>"></script>
    <link href="<?php echo e(asset('assets/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('assets/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<?php endif; ?>

<?php /**PATH D:\laragon\www\monitoring-produksi-ads\resources\views/Template/head.blade.php ENDPATH**/ ?>