<footer id="footer" class="footer">
    <div class="copyright">
        &copy; Copyright <?php echo e(date('Y')); ?> <strong><span>KGDR</span></strong>. All Rights Reserved
    </div>
</footer><?php /**PATH D:\laragon\www\monitoring-produksi-ads\resources\views/Template/footer.blade.php ENDPATH**/ ?>