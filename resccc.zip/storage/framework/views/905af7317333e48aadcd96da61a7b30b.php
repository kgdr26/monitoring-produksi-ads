
<header id="header" class="header fixed-top d-flex align-items-center">

    <div class="d-flex align-items-center justify-content-between">
        <a href="" class="logo d-flex align-items-center">
            <img src="assets/img/logo.png" alt="">
            <span class="d-none d-lg-block">Monitoring</span>
        </a>
        <i class="bi bi-list toggle-sidebar-btn"></i>
    </div>

    <div class="search-bar">

    </div>

    <nav class="header-nav ms-auto">
        
    </nav>

</header>

<?php /**PATH D:\laragon\www\monitoring-produksi-ads\resources\views/Template/header.blade.php ENDPATH**/ ?>