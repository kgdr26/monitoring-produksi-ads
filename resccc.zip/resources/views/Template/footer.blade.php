<footer id="footer" class="footer">
    <div class="copyright">
        &copy; Copyright {{date('Y')}} <strong><span>KGDR</span></strong>. All Rights Reserved
    </div>
</footer>